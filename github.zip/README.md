# Monorepo Proje

Bu proje, backend (Node.js/Express) ve frontend (React/Vite) uygulamalarını tek bir depo altında barındırır.

## Klasör Yapısı
- `backend/` : API ve sunucu tarafı kodları
- `frontend/` : React tabanlı kullanıcı arayüzü

## Kurulum ve Çalıştırma
Her klasörün içinde kendi README dosyası ve kurulum talimatları yer alacaktır. 