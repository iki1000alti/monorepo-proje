# Backend

Bu klasör Node.js/Express tabanlı API ve sunucu kodlarını içerir.

## Kurulum

```bash
npm install
```

## Çalıştırma

```bash
npm start
``` 